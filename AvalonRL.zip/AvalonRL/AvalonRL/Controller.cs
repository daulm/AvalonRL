﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AvalonRL
{
    public partial class Controller : Form
    {
        public struct StateResult
        {
            public int spyWins;
            public int goodWins;
        }

        private int merlinAlg = 0;
        private int spyAlg = 0;
        private int normalAlg = 0;

        private Dictionary<string, StateResult> learningMap;

        public Controller()
        {
            InitializeComponent();
            learningMap = new Dictionary<string, StateResult>(20000000);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            int count = 0;
            int spyWins = 0;
            int goodWins = 0;

            UpdateAlgoritms();

            if (Int32.TryParse(textBox1.Text, out count))
            {
                for (int i = 0; i < count; i++)
                {
                    BotGame7 newGame = new BotGame7(spyAlg, merlinAlg, normalAlg);
                    if (newGame.Play(learningMap) == 0)
                    {
                        spyWins++;
                    }
                    else
                    {
                        goodWins++;
                    }
                    newGame.RecordGame(learningMap);
                }

            }
            //MessageBox.Show(spyWins.ToString() + " | " + goodWins.ToString());
            label5.Text = goodWins.ToString();
            label6.Text = spyWins.ToString();
            label9.Text = ((float)goodWins / (goodWins + spyWins)).ToString();
            label10.Text = ((float)spyWins / (goodWins + spyWins)).ToString();
            label1.Text = learningMap.Count.ToString();
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void UpdateAlgoritms()
        {
            if (radioButton1.Checked)
            {
                spyAlg = 2;
            }
            if (radioButton2.Checked)
            {
                spyAlg = 1;
            }
            if (radioButton3.Checked)
            {
                spyAlg = 0;
            }
            if (radioButton4.Checked)
            {
                normalAlg = 2;
            }
            if (radioButton5.Checked)
            {
                normalAlg = 1;
            }
            if (radioButton6.Checked)
            {
                normalAlg = 0;
            }
            if (radioButton7.Checked)
            {
                merlinAlg = 2;
            }
            if (radioButton8.Checked)
            {
                merlinAlg = 1;
            }
            if (radioButton9.Checked)
            {
                merlinAlg = 0;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
