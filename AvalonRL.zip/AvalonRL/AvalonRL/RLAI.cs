﻿using System;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace AvalonRL
{
    public class RLAI
    {
        private int alg;
        private int role;
        private List<int> spyLoc;
        private int position;
        List<string> captMap;
        private int gameSize;
        List<int> positions;
        int epsilon;


        private static Random rng = new Random();

        public RLAI(int algorithm, int argrole, int pos, int size)
	    {
            role = argrole;
            alg = algorithm;
            position = pos;
            gameSize = size;
            spyLoc = new List<int>();
            positions = new List<int>();
            epsilon = 10;
            captMap = new List<string>();
            for (int i = 0; i < size; i++) { captMap.Add("A"); }
	    }

        public void LocateSpies(List<int> spies)
        {
            //the game will only call this for spies and merlin
            spyLoc = spies;
            for (int i = 0; i < gameSize; i++ ) 
            {
                if(spies.Contains(i)){ positions.Add(0); }
                else { positions.Add(1);}
            }
            captMap.Clear();
            captMap = CaptainPatterns(positions);
        }

        public bool CastVote(GameState state, Dictionary<string, Controller.StateResult> learningMap)
        {
            if (alg == 0)
            {
                if (state.GetCurrentRound() == 4) return true;
                return rng.Next(2) == 1;
            }
            else if (alg == 1)
            {
                // check epsilon chance to explore
                if (rng.Next(epsilon) == 0) { return rng.Next(2) == 1; }
            }

            // build possible key values and check for the best option
            List<string> decisions = new List<string>(new string[] { "0", "1" });
            List<string> keys = new List<string>();
            string key = "";
            string onTeam = "0";
            int memsuccess = 0; // number of times a team member was on a team that succeeded
            int memfail = 0;
            int voteSuccessNum = 0;
            int voteFailNum = 0;
            int spycount = 0;
            foreach (int member in state.GetCurrentTeam())
            {
                if (spyLoc.Contains(member)) { spycount++; }
                memsuccess += state.GetMissionSuccess()[member];
                memfail += state.GetMissionFails()[member];
                voteSuccessNum += state.GetVoteSuccess()[member];
                voteFailNum += state.GetVoteFails()[member];
            }
            //MessageBox.Show(captMap.Count.ToString() + " | " + state.GetCurrentCaptain().ToString());
            string next4capt = captMap[state.GetCurrentCaptain()];
            string captainSpy = "0";
            if (positions.Count > state.GetCurrentCaptain())
            {
                if (positions[state.GetCurrentCaptain()] > 0) { captainSpy = "1"; }
            }

            if (state.GetCurrentTeam().Contains(position)) { onTeam = "1"; }

            string missionHist = MissionHistMap(state.GetMissionHist(), state.GetCurrentMission());
                
            if (role == 2)
            {
                foreach (string decision in decisions)
                {
                    key = "E0" + decision + spycount.ToString() + onTeam + state.GetCurrentRound().ToString() + captainSpy + next4capt + missionHist + memsuccess.ToString() + memfail.ToString();
                    keys.Add(key);
                }
                return decisions[BestChoice(learningMap, keys)] == "1";
            }
            if (role == 1)
            {
                foreach (string decision in decisions)
                {
                    key = "G0" + decision + onTeam + state.GetCurrentRound().ToString() + missionHist + memsuccess.ToString() + memfail.ToString() + voteSuccessNum.ToString() + voteFailNum.ToString();
                    keys.Add(key);
                }
                return decisions[BestChoice(learningMap, keys)] == "1";
            }
            if (role == 0)
            {
                foreach (string decision in decisions)
                {
                    key = "A0" + decision + spycount.ToString() + onTeam + state.GetCurrentRound().ToString() + next4capt + missionHist + memsuccess.ToString() + memfail.ToString();
                    keys.Add(key);
                }
                return decisions[BestChoice(learningMap, keys)] == "1";
            }

            return rng.Next(2) == 1;
        }

        public List<int> ChooseTeam(GameState state, int size, Dictionary<string, Controller.StateResult> learningMap)
        {
            List<int> team = new List<int>();
            if (alg == 0 || (alg == 1 && rng.Next(epsilon) == 0))
            {
                int pick;
                while (team.Count < size)
                {
                    pick = rng.Next(7);
                    if (!team.Contains(pick))
                    {
                        team.Add(pick);
                    }
                }
                return team;
            }

            //build all possible teams
            List<List<int>> teams = GetAllTeams(new List<int>(), size);
            List<string> keys = new List<string>();
            Dictionary<string, int> keyMap = new Dictionary<string, int>();
            string key = "";
            int teamindex = 0;
            string next4capt = captMap[position];
            string missionHist = MissionHistMap(state.GetMissionHist(), state.GetCurrentMission());
            int index = 0;

            foreach (List<int> tryTeam in teams)
            {
                key = "";
                int spycount = 0;
                int memsuccess = 0;
                int memfail = 0;
                int voteSuccessNum = 0;
                int voteFailNum = 0;
                string onTeam = "0";
                if (tryTeam.Contains(position)) { onTeam = "1"; }
                foreach (int member in tryTeam)
                {
                    if (spyLoc.Contains(member)) { spycount++; }
                    memsuccess += state.GetMissionSuccess()[member];
                    memfail += state.GetMissionFails()[member];
                    voteSuccessNum += state.GetVoteSuccess()[member];
                    voteFailNum += state.GetVoteFails()[member];
                }
                if (role == 2)
                {
                    key = "F0" + spycount.ToString() + onTeam + state.GetCurrentRound().ToString() + next4capt + missionHist + memsuccess.ToString() + memfail.ToString();
                }
                if (role == 1)
                {
                    key = "H0" + onTeam + state.GetCurrentRound().ToString() + missionHist + memsuccess.ToString() + memfail.ToString() + voteSuccessNum.ToString() + voteFailNum.ToString();
                }
                if (role == 0)
                {
                    key = "B0" + spycount.ToString() + onTeam + state.GetCurrentRound().ToString() + next4capt + missionHist + memsuccess.ToString() + memfail.ToString();
                }
                
                if (keyMap.TryGetValue(key, out teamindex))
                {
                    if (rng.Next(3) == 0)
                    {
                        keyMap[key] = index;
                    }
                }
                else
                {
                    keyMap.Add(key, index);
                    keys.Add(key);
                }

                index++;
            }
            //MessageBox.Show(allTeams);

            index = keyMap[keys[BestChoice(learningMap, keys)]];

            return teams[index];
        }

        public int MissionPlay(GameState state, Dictionary<string, Controller.StateResult> learningMap)
        {
            //only spies should be asked to play
            if (role > 0) { return 0; }


            if (alg == 0 || (alg == 1 && rng.Next(epsilon) == 0)) { return rng.Next(2); }

            //return rng.Next(2); //delete this after testing

            List<string> decisions = new List<string>(new string[] { "1", "0" });
            List<string> keys = new List<string>();
            string key = "";
            int memsuccess = 0; // number of times a team member was on a team that succeeded
            int memfail = 0;
            int voteSuccessNum = 0;
            int voteFailNum = 0;
            int spycount = 0;
            foreach (int member in state.GetCurrentTeam())
            {
                if (spyLoc.Contains(member)) { spycount++; }
                memsuccess += state.GetMissionSuccess()[member];
                memfail += state.GetMissionFails()[member];
                voteSuccessNum += state.GetVoteSuccess()[member];
                voteFailNum += state.GetVoteFails()[member];
            }
            string next4capt = captMap[state.GetCurrentCaptain()];

            string missionHist = MissionHistMap(state.GetMissionHist(), state.GetCurrentMission());
            //key = "C0" + missionDecision + spycount.ToString() + next4capt + missionHist + memsuccess.ToString() + memfail.ToString();
            foreach (string decision in decisions)
            {
                key = "C0" + decision + spycount.ToString() + next4capt + missionHist + memsuccess.ToString() + memfail.ToString();
                keys.Add(key);
            }
            

            if (BestChoice(learningMap, keys) == 0) { return 1; }
            return 0;

        }

        public int PickMerlin(GameState state, Dictionary<string, Controller.StateResult> learningMap)
        {
            if (alg == 0 || (alg == 1 && rng.Next(epsilon) == 0))
            {
                int guess;
                while (true)
                {
                    guess = rng.Next(7);
                    if (!spyLoc.Contains(guess)) return guess;
                }
            }
            string key = "";
            List<string> keys = new List<string>();
            List<int> keyMap = new List<int>();
            List<int> knightPerfectVotes = new List<int>();
            List<int> knightSpyVotes = new List<int>();
            List<int> knightPerfectTeams = new List<int>();
            List<int> knightSpyTeams = new List<int>();
            for (int i = 0; i < gameSize; i++)
            {
                knightPerfectVotes.Add(0);
                knightSpyVotes.Add(0);
                knightPerfectTeams.Add(0);
                knightSpyTeams.Add(0);
            }

            //loop through all rounds
            foreach (Round round in state.GetRounds())
            {
                //set values at this round
                int spycount = 0;
                foreach (int member in round.team)
                {
                    if (positions[member] == 0) { spycount++; }
                }
                //loop through each position
                for (int i = 0; i < gameSize; i++)
                {
                    if (spycount > 0)
                    {
                        if (round.votes[i]) { knightSpyVotes[i]++; }
                        if (i == round.captain) { knightSpyTeams[i]++; }
                    }
                    else
                    {
                        if (round.votes[i]) { knightPerfectVotes[i]++; }
                        if (i == round.captain) { knightPerfectTeams[i]++; }
                    }
                }

            }
            string missionHist = MissionHistMap(state.GetMissionHist(), state.GetSuccessCount()+state.GetFailCount());
            for (int i = 0; i < gameSize; i++)
            {
                if (positions[i] == 1)
                {
                    key = "D0" + missionHist + knightPerfectVotes[i].ToString() + "|" + knightSpyVotes[i].ToString() + "|" + knightPerfectTeams[i].ToString() + knightSpyTeams[i].ToString();
                    keys.Add(key);
                    /*Controller.StateResult winLoss;
                    int count = 0;
                    if (learningMap.TryGetValue(key, out winLoss))
                    {
                        count = winLoss.goodWins + winLoss.spyWins;
                    }
                    MessageBox.Show(key + " | " + count.ToString());*/
                    keyMap.Add(i);
                }
            }
            return keyMap[BestChoice(learningMap, keys)];
        }

        private int BestChoice(Dictionary<string, Controller.StateResult> learningMap, List<string> keys)
        {
            float winRate = 0.0f;
            //float winRateConf = 0.0f;
            int maxIndex = 0;
            Controller.StateResult winLoss;
            int myWins;
            float z = 1.96f;
            int count = 0;

            foreach (string key in keys)
            {
                if (learningMap.TryGetValue(key, out winLoss))
                {
                    if(role == 0){ myWins = winLoss.spyWins;}
                    else { myWins = winLoss.goodWins;}
                    float currRate = (float)(myWins + z * z / 2)/(winLoss.goodWins + winLoss.spyWins + z * z);  //wilson score interval
                    if (currRate > winRate)
                    {
                        maxIndex = count;
                        winRate = currRate;
                    }
                }
                else
                {
                    if (winRate < 0.5f) 
                    {
                        maxIndex = count;
                        winRate = 0.5f;
                    }
                }
                count++;   
            }
            return maxIndex;

        }

        public static List<string> CaptainPatterns(List<int> positions)
        {
            // this function takes in a list of the roles in the game and returns the mapping for the pattern of the next 4 captains
            // for each position for a captain
            List<string> map = new List<string>();

            for (int i = 0; i < positions.Count; i++)
            {
                string pattern = "";
                for (int j = i + 1; j < i + 5; j++)
                {
                    if (positions[j % positions.Count] == 0) { pattern += "S"; }
                    else { pattern += "G"; }
                }
                switch (pattern)
                {
                    case "GGGG": map.Add("A");   break;
                    case "SGGG": map.Add("B"); break;
                    case "GSGG": map.Add("C"); break;
                    case "GGSG": map.Add("D"); break;
                    case "GGGS": map.Add("E"); break;
                    case "SSGG": map.Add("F"); break;
                    case "SGSG": map.Add("G"); break;
                    case "SGGS": map.Add("H"); break;
                    case "GSSG": map.Add("I"); break;
                    case "GSGS": map.Add("J"); break;
                    case "GGSS": map.Add("K"); break;
                    case "SSSG": map.Add("L"); break;
                    case "SSGS": map.Add("M"); break;
                    case "SGSS": map.Add("N"); break;
                    case "GSSS": map.Add("O"); break;               
                    default: map.Add("X"); break;
                }
            }

            return map;
        }  //end func CaptainPatterns

        public static string MissionHistMap(List<int> missionHist, int currRnd)
        {
            if (currRnd == 0) { return "A"; }
            string pattern = "";
            for (int i = 0; i < currRnd; i++)
            {
                if (missionHist[i] == 0) { pattern += "F"; }
                else { pattern += "P"; }
            }
            switch (pattern)
            {
                case "": return "A"; 
                case "P": return "B";
                case "F": return "C";
                case "PP": return "D";
                case "PF": return "E";
                case "FP": return "F";
                case "FF": return "G";
                case "PPP": return "H";
                case "PPF": return "I";
                case "PFP": return "J";
                case "FPP": return "K";
                case "PFF": return "L";
                case "FPF": return "M";
                case "FFP": return "N";
                case "FFF": return "O";
                case "PPFP": return "P";
                case "PFPP": return "Q";
                case "FPPP": return "R";
                case "PFFP": return "S";
                case "FPFP": return "T";
                case "FFPP": return "U";
                case "PFFF": return "V";
                case "FPFF": return "W";
                case "FFPF": return "X";
                case "PPFF": return "Y";
                case "PFPF": return "Z";
                case "FPPF": return "a";
                case "PFFPP": return "b";
                case "PFFPF": return "c";
                case "PPFFP": return "d";
                case "PPFFF": return "e";
                case "FPFPP": return "f";
                case "FPFPF": return "g";
                case "FFPPP": return "h";
                case "FFPPF": return "i";
                case "PFPFP": return "j";
                case "PFPFF": return "k";
                case "FPPFP": return "l";
                case "FPPFF": return "m";
                default: return "x";
            }
        }  //end missionHistoryMap()

        private List<string> Shuffle(List<string> list)
        {
            int n = list.Count;
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                string value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
            return list;
        }

        private List<List<int>> GetAllTeams(List<int> currmem, int tSize)
        {
            List<List<int>> teams = new List<List<int>>();
            List<int> currentMembers = new List<int>(currmem);
            int start = 0;
            if (currentMembers.Count > 0) { start = currentMembers[currentMembers.Count - 1] + 1; }
            for (int i = start; i < gameSize-tSize+1; i++)
            {
                currentMembers.Add(i);
                if(tSize > 0){
                    teams.AddRange(GetAllTeams(currentMembers, tSize - 1));
                }
                else
                {
                    teams.Add(currentMembers);
                }
                currentMembers.Remove(i);    
            }
            return teams;
        }
    }
}
