﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AvalonRL
{
    public class Round
    {
        public int captain;
        public int missionNum;  //0-4
        public int missionResult;
        public List<int> team;
        public List<bool> votes;
        public bool greenLight;  //did the mission take place this round?
        public int numFails;
        public List<int> playedFail;

        public Round(int capt, int misNo)
        {
            captain = capt;
            missionNum = misNo;
            numFails = 0;
            missionResult = -1;
            team = new List<int>();
            playedFail = new List<int>();
            greenLight = false;
        }

        public void SetFail(int player)
        {
            playedFail.Add(player);
            numFails++;
        }
    }
}
