﻿using System;
using System.Collections.Generic;

namespace AvalonRL
{
    public class GameState
    {
        private int numPlayers;
        private int missionsSuccess;
        private int missionsFail;
        private int currentRound;
        private int currCaptain;
        private int currMission;
        private int totalRounds;
        private List<int> currTeam;
        private List<Round> rounds;
        private List<int> missionHist;
        private int merlinSelected;
        private int finalResult;
        private List<int> missionSuccess;
        private List<int> missionFails;
        private List<int> voteSuccess;
        private List<int> voteFails;

        public GameState(int num)
	    {
            numPlayers = num;
            missionsSuccess = 0;
            missionsFail = 0;
            currentRound = 0;
            currCaptain = 0;
            currMission = 0;
            totalRounds = 0;
            currTeam = new List<int>();
            missionHist = new List<int>();
            rounds = new List<Round>();
            missionSuccess = new List<int>();
            missionFails = new List<int>();
            voteSuccess = new List<int>();
            voteFails = new List<int>();
            rounds.Add(new Round(0, 0));
            for (int i = 0; i < numPlayers; i++)
            {
                missionSuccess.Add(0);
                missionFails.Add(0);
                voteSuccess.Add(0);
                voteFails.Add(0);
            }
	    }


        public void SetTeam(List<int> newTeam)
        {
            currTeam = new List<int>(newTeam);
            rounds[totalRounds].team = new List<int>(newTeam);
        }

        public void SetVotes(List<bool> vote)
        {
            rounds[totalRounds].votes = new List<bool>(vote);
        }

        public void SetMissionFail(int player)
        {
            rounds[totalRounds].SetFail(player);
        }

        public void SetMissionResult(int result)
        {
            rounds[totalRounds].missionResult = result;
            rounds[totalRounds].greenLight = true;
            if (result == 0)
            {
                missionsFail++;
                foreach (int member in currTeam) { missionFails[member]++; }
                for (int i = 0; i < numPlayers; i++)
                {
                    if (rounds[totalRounds].votes[i]) { voteFails[i]++; }
                }
            }
            else
            {
                missionsSuccess++;
                foreach (int member in currTeam) { missionSuccess[member]++; }
                for (int i = 0; i < numPlayers; i++)
                {
                    if (rounds[totalRounds].votes[i]) { voteSuccess[i]++; }
                }
            }
            missionHist.Add(result);
        }

        public void SetMerlinPick(int pick)
        {
            merlinSelected = pick;
        }

        public void NextRound()
        {
            currentRound++;
            if (rounds[totalRounds].missionResult >= 0)
            {
                currentRound = 0;
                currMission++;
            }
            totalRounds++;
            currCaptain = (currCaptain + 1) % numPlayers;
            rounds.Add(new Round(currCaptain, currMission));
        }

        public void SetFinalResult(int result)
        {
            finalResult = result;
        }

        public int GetFailCount()
        {
            return missionsFail;
        }

        public int GetSuccessCount()
        {
            return missionsSuccess;
        }

        public List<int> GetCurrentTeam()
        {
            return currTeam;
        }

        public int GetCurrentRound()
        {
            return currentRound;
        }

        public int GetCurrentCaptain()
        {
            return currCaptain;
        }

        public List<int> GetMissionHist()
        {
            return missionHist;
        }

        public int GetCurrentMission() { return missionHist.Count; }

        public int GetMerlinPick() { return merlinSelected; }

        public List<int> GetMissionSuccess() { return missionSuccess; }

        public List<int> GetMissionFails() { return missionFails; }

        public List<int> GetVoteSuccess() { return voteSuccess; }

        public List<int> GetVoteFails() { return voteFails; }

        public int GetFinalResult() {  return finalResult;  }

        public List<Round> GetRounds() { return rounds;  }

    }
}