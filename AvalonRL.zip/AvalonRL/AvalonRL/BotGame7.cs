﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace AvalonRL
{
    public class BotGame7
    {
        private int spyAlg;
        private int merlinAlg;
        private int normalAlg;
        private List<int> positions;
        private int result;
        private GameState gamestate;
        private List<RLAI> players;
        private static List<int> teamSize = new List<int>() { 2, 3, 3, 4, 4 };
        private static List<int> failsReq = new List<int>() { 1, 1, 1, 2, 1 };
        private List<int> spyLocations;
        private static int gameSize = 7;


        private static Random rng = new Random();


        public BotGame7(int spyAlgorithm, int merlinAlgorithm, int normalAlgorithm)
        {
            spyAlg = spyAlgorithm;
            merlinAlg = merlinAlgorithm;
            normalAlg = normalAlgorithm;
            gamestate = new GameState(gameSize);
            players = new List<RLAI>();
            spyLocations = new List<int>();
            result = -1;
            //randomly set the positions
            positions = Shuffle(new List<int>(new int[] { 0, 0, 0, 2, 1, 1, 1 }));

            //create the bots
            for (int i = 0; i < positions.Count; i++)
            {
                int role = positions[i];
                int alg = -1;
                switch (role)
                {
                    case 0: alg = spyAlg; break;
                    case 1: alg = normalAlg; break;
                    case 2: alg = merlinAlg; break;
                }
                players.Add(new RLAI(alg, role, i, gameSize));
                //set the spy locations to be shared later
                if(role == 0) spyLocations.Add(i);
            }

        }

        public int Play(Dictionary<string, Controller.StateResult> learningMap)
        {
            int totalRnd = 0;
            int captain = 0;
            int mission = 0;
            List<bool> votes = new List<bool>();

            for (int i = 0; i < positions.Count; i++)
            {
                // send spy locations to spies and merlin
                int role = positions[i];
                if(role == 0 || role == 2) players[i].LocateSpies(spyLocations);
            }

            captain = totalRnd % gameSize;

            while (result < 0)
            {
                //choose team
                gamestate.SetTeam(players[captain].ChooseTeam(gamestate, teamSize[mission], learningMap));
                bool lastvote;
                int numPass = 0;
                int missionFails = 0;
                //vote
                for (int i = 0; i < players.Count; i++)
                {
                    lastvote = players[i].CastVote(gamestate, learningMap);
                    if (lastvote)
                    {
                        numPass++;
                    }
                    votes.Add(lastvote);
                }

                gamestate.SetVotes(votes);

                if ((float)numPass > (float)gameSize / 2)
                {
                    //go on mission
                    foreach (int member in gamestate.GetCurrentTeam())
                    {
                        if(spyLocations.Contains(member))
                        {
                            int fail = players[member].MissionPlay(gamestate, learningMap);
                            missionFails += fail;
                            if (fail > 0)
                            {
                                gamestate.SetMissionFail(member);
                            }
                        }
                        
                    }
                    if (missionFails >= failsReq[mission])
                    {
                        // The mission failed
                        gamestate.SetMissionResult(0);
                        if (gamestate.GetFailCount() == 3)
                        {
                            //spies win
                            result = 0;
                            gamestate.SetFinalResult(result);
                            return result;
                        }
                    }
                    else
                    {
                        // The mission passed
                        gamestate.SetMissionResult(1);
                        if (gamestate.GetSuccessCount() == 3)
                        {
                            //Good guys win 3
                            //choose merlin
                            int merlinPick = players[positions.IndexOf(0)].PickMerlin(gamestate, learningMap);
                            gamestate.SetMerlinPick(merlinPick);
                            if (merlinPick == positions.IndexOf(2))
                            {
                                //spies picked merlin and win
                                result = 0;
                                gamestate.SetFinalResult(result);
                                return result;
                            }
                            else
                            {
                                //good guys win
                                result = 1;
                                gamestate.SetFinalResult(result);
                                return result;
                            }                           
                        }
                    }

                    if (result < 0)
                    {
                        //the game hasn't ended
                        totalRnd++;
                        captain = totalRnd % gameSize;
                        mission++;
                        gamestate.NextRound();
                    }  
                }
                else
                {
                    //vote didn't pass
                    if(gamestate.GetCurrentRound() == 4)
                    {
                        //spies win
                        result = 0;
                        gamestate.SetFinalResult(result);
                        return result;
                    }
                    else
                    {
                        totalRnd++;
                        captain = totalRnd % gameSize;
                        gamestate.NextRound();
                    }
                }
                votes.Clear();
            }
            return result;
        }

        public string ShowOutput()
        {
            string json = new JavaScriptSerializer().Serialize(gamestate.GetMissionHist());
            json = json + new JavaScriptSerializer().Serialize(positions);
            return json;
        }

        public void RecordGame(Dictionary<string, Controller.StateResult> learningMap)
        {
            // make sure we have a game result
            if (result < 0) return;
            List<string> captMap = RLAI.CaptainPatterns(positions);
            int captain = 0;
            int missionNum = 0;
            string missionHist = "";
            int currentRound = 0;
            string captainSpy = "0";
            List<int> missionFail = new List<int>(new int[] { 0, 0, 0, 0, 0, 0, 0 });
            List<int> missionSuccess = new List<int>(new int[] { 0, 0, 0, 0, 0, 0, 0 });
            List<int> voteFail = new List<int>(new int[] { 0, 0, 0, 0, 0, 0, 0 });
            List<int> voteSuccess = new List<int>(new int[] { 0, 0, 0, 0, 0, 0, 0 });
            string voteDecision = "";
            string onTeam = "";
            string key = "";
            string missionDecision = "";
            List<int> knightPerfectVotes = new List<int>(new int[] { 0, 0, 0, 0, 0, 0, 0 });
            List<int> knightSpyVotes = new List<int>(new int[] { 0, 0, 0, 0, 0, 0, 0 });
            List<int> knightPerfectTeams = new List<int>(new int[] { 0, 0, 0, 0, 0, 0, 0 });
            List<int> knightSpyTeams = new List<int>(new int[] { 0, 0, 0, 0, 0, 0, 0 });

            //loop through all rounds
            foreach (Round round in gamestate.GetRounds())
            {
                //set values at this round
                int spycount = 0;
                int memsuccess = 0; // number of times a team member was on a team that succeeded
                int memfail = 0;
                int voteSuccessNum = 0;
                int voteFailNum = 0;
                captainSpy = "0";
                captain = round.captain;
                //number of spies on team
                foreach(int member in round.team)
                {
                    if (positions[member] == 0){ spycount++; }
                    memsuccess += missionSuccess[member];
                    memfail += missionFail[member];
                    voteSuccessNum += voteSuccess[member];
                    voteFailNum += voteFail[member];
                    //update counters for future use
                    if (round.greenLight)
                    {
                        if (round.missionResult == 0) { missionFail[member]++; }
                        else { missionSuccess[member]++; }
                    }
                }
                string next4capt = captMap[captain];

                if (positions[captain] > 0) { captainSpy = "1"; }

                missionHist = RLAI.MissionHistMap(gamestate.GetMissionHist(), missionNum);
                
                //loop through each position
                for (int i = 0; i < gameSize; i++)
                {
                    if (round.votes[i]) { voteDecision = "1"; }
                    else { voteDecision = "0"; }
                    if (round.team.Contains(i)) { onTeam = "1"; }
                    else { onTeam = "0"; }

                    if (spycount > 0)
                    {
                        if (round.votes[i]) { knightSpyVotes[i]++; }
                        if (i == captain) { knightSpyTeams[i]++; }
                    }
                    else
                    {
                        if (round.votes[i]) { knightPerfectVotes[i]++; }
                        if (i == captain) { knightPerfectTeams[i]++; }
                    }

                    if (positions[i] == 2)
                    { // vote decision for merlin
                        key = "E0" + voteDecision + spycount.ToString() + onTeam + currentRound.ToString() + captainSpy + next4capt + missionHist + memsuccess.ToString() + memfail.ToString();
                        UpdateAI(learningMap, key, result);
                        // team choice for merlin
                        if (i == captain)
                        {
                            key = "F0" + spycount.ToString() + onTeam + currentRound.ToString() + next4capt + missionHist + memsuccess.ToString() + memfail.ToString();
                            UpdateAI(learningMap, key, result);
                        } 
                    }
                    if (positions[i] == 1)
                    {
                        key = "G0" + voteDecision + onTeam + currentRound.ToString() + missionHist + memsuccess.ToString() + memfail.ToString() + voteSuccessNum.ToString() + voteFailNum.ToString();
                        UpdateAI(learningMap, key, result);
                        if (i == captain)
                        {
                            key = "H0" + onTeam + currentRound.ToString() + missionHist + memsuccess.ToString() + memfail.ToString() + voteSuccessNum.ToString() + voteFailNum.ToString();
                            UpdateAI(learningMap, key, result);
                        }
                    }
                    if (positions[i] == 0)
                    {
                        key = "A0" + voteDecision + spycount.ToString() + onTeam + currentRound.ToString() + next4capt + missionHist + memsuccess.ToString() + memfail.ToString();
                        UpdateAI(learningMap, key, result);
                        if (i == captain)
                        {
                            key = "B0" + spycount.ToString() + onTeam + currentRound.ToString() + next4capt + missionHist + memsuccess.ToString() + memfail.ToString();
                            UpdateAI(learningMap, key, result);
                        }
                        if (round.team.Contains(i))
                        {
                            if (round.playedFail.Contains(i)) { missionDecision = "1"; }
                            else { missionDecision = "0"; }
                            key = "C0" + missionDecision + spycount.ToString() + next4capt + missionHist + memsuccess.ToString() + memfail.ToString();
                            UpdateAI(learningMap, key, result);
                        }
                    }
                    //update vote counters for future use
                    if (round.greenLight)
                    {
                        if (round.missionResult == 0) {
                            if (round.votes[i]) { voteFail[i]++; }
                        }
                        else {
                            if (round.votes[i]) { voteSuccess[i]++; }
                        }
                    }
                }

                currentRound++;
                if (round.greenLight)
                {
                    currentRound = 0;
                    missionNum++;
                }

            }
            //create key for merlin decision
            if (gamestate.GetSuccessCount() == 3)
            {
                missionHist = RLAI.MissionHistMap(gamestate.GetMissionHist(), missionNum);
                
                for (int i = 0; i < gameSize; i++)
                {
                    if (positions[i] == 1)
                    {
                        key = "D0" + missionHist + knightPerfectVotes[i].ToString() + "|" + knightSpyVotes[i].ToString() + "|" + knightPerfectTeams[i].ToString() + knightSpyTeams[i].ToString();
                        UpdateAI(learningMap, key, 1);
                    }
                    if (positions[i] == 2)
                    {
                        key = "D0" + missionHist + knightPerfectVotes[i].ToString() + "|" + knightSpyVotes[i].ToString() + "|" + knightPerfectTeams[i].ToString() + knightSpyTeams[i].ToString();
                        UpdateAI(learningMap, key, 0);
                        //MessageBox.Show(key + " | " + gamestate.GetRounds().Count.ToString());
                    }
                }
                    
            }
            return;
        }

        private void UpdateAI(Dictionary<string, Controller.StateResult> learningMap, string key, int res)
        {
            Controller.StateResult winLoss;
            if (learningMap.TryGetValue(key, out winLoss))
            {
                // a decision state exists already, add to the correct win counter and update it
                if (res == 0) { winLoss.spyWins++; }
                else { winLoss.goodWins++; }
            }
            else
            {
                //add a record for the decision-state
                if (res == 0)
                {
                    winLoss.spyWins = 1;
                    winLoss.goodWins = 0;
                }
                else
                {
                    winLoss.spyWins = 0;
                    winLoss.goodWins = 1;
                }
            }
            learningMap[key] = winLoss;
        }

        private List<int> Shuffle(List<int> list)
        {
            int n = list.Count;
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                int value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
            return list;
        }
    }
}